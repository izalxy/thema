module.exports = {
  BOT_TOKEN: "YOUR_TOKEN_BOT_API",
  OWNER_ID: ["6142885267"],
};